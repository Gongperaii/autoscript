#!/bin/bash
# Script by : _Gongperai_
opensshport="$(netstat -ntlp | grep -i ssh | grep -i 0.0.0.0 | awk '{print $4}' | cut -d: -f2)"
dropbearport="$(netstat -nlpt | grep -i dropbear | grep -i 0.0.0.0 | awk '{print $4}' | cut -d: -f2)"
stunnel4port="$(netstat -nlpt | grep -i stunnel | grep -i 0.0.0.0 | awk '{print $4}' | cut -d: -f2)"
openvpnport="$(netstat -nlpt | grep -i openvpn | grep -i 0.0.0.0 | awk '{print $4}' | cut -d: -f2)"
squidport="$(cat /etc/squid3/squid.conf | grep -i http_port | awk '{print $2}')"
clear
echo -e "\e[0m                                                   "
echo -e "\e[94m[][][]======================================[][][]"
echo -e "\e[0m                                                   "
echo -e "\e[93m           AutoScriptVPS by  _Gongperai_           "
echo -e "\e[0m                                                   "
echo -e "         Port OpenSSH    :  "$opensshport
echo -e "         Port Dropbear   :  "$dropbearport
echo -e "         Port SSL        :  "$stunnel4port
echo -e "         Port Squid      :  "$squidport
echo -e "         Port OpenVPN    :  "$openvpnport
echo -e "\e[0m                                                   "
echo -e "\e[94m[][][]======================================[][][]\e[0m"
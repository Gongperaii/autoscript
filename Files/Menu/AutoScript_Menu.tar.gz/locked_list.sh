#!/bin/bash
# Script by : _Gongperai_
if [ -f "$FILE" ];
then
cd
nano /etc/Locked_List.txt
else
cd
nano /etc/Locked_List.txt
fi